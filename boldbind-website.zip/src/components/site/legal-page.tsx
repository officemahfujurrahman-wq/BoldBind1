"use client";

import { Reveal } from "./reveal";

interface LegalSection {
  heading?: string;
  text?: string;
}

const PRIVACY: LegalSection[] = [
  {
    text: 'Bold Bind ("we", "us") is a creative and digital agency based in Dhaka, Bangladesh. This policy explains what information we collect through www.boldbind.com and our services, how we use it, and the choices you have.',
  },
  {
    heading: "Information we collect",
    text: "We collect information you provide directly — such as your name, email, phone number, company, and project details — when you contact us, book a consultation, or subscribe to updates. We also collect basic analytics (pages viewed, referrer, device) via privacy-friendly tools.",
  },
  {
    heading: "How we use information",
    text: "We use your information to respond to inquiries, deliver services you've engaged us for, send occasional updates you've opted into, and improve our website. We do not sell your personal information.",
  },
  {
    heading: "Sharing",
    text: "We share information only with trusted subprocessors (hosting, email, analytics) as needed to run our business, and when required by law.",
  },
  {
    heading: "Retention",
    text: "We keep project and contact records for as long as needed to serve you and to meet legal or accounting obligations. You can request deletion at any time.",
  },
  {
    heading: "Your rights",
    text: "You can request access, correction, or deletion of your personal information by emailing contact@boldbind.com. We'll respond within 30 days.",
  },
  {
    heading: "Cookies",
    text: "We use essential cookies to run the site and optional analytics cookies to understand usage. You can control cookies through your browser settings.",
  },
  {
    heading: "Contact",
    text: "Questions? Email contact@boldbind.com or write to Bold Bind, Section 10, Block-A, Lane 14, House 4, Mirpur, Dhaka, Bangladesh.",
  },
];

const TERMS: LegalSection[] = [
  {
    text: "By accessing www.boldbind.com or engaging Bold Bind for services, you agree to these Terms. If you do not agree, please do not use the site or services.",
  },
  {
    heading: "Services",
    text: "Bold Bind provides creative, marketing, design, automation, consulting, and video production services. Specific deliverables, timelines, and fees are defined in a written proposal or statement of work.",
  },
  {
    heading: "Client responsibilities",
    text: "Clients agree to provide timely feedback, required assets, and payment per the agreed schedule. Delays in client input may shift timelines.",
  },
  {
    heading: "Fees & payment",
    text: "Fees are invoiced per the SOW. Unless otherwise agreed, invoices are due within 15 days. Late payments may incur reasonable interest and pause active work.",
  },
  {
    heading: "Intellectual property",
    text: "Upon full payment, ownership of final approved deliverables transfers to the client. Bold Bind retains rights to preliminary concepts and reserves the right to feature the work in its portfolio unless agreed otherwise.",
  },
  {
    heading: "Confidentiality",
    text: "We treat client information as confidential and will not share it outside our team or trusted subprocessors without permission.",
  },
  {
    heading: "Limitation of liability",
    text: 'Services are provided "as is". To the maximum extent permitted by law, Bold Bind\'s total liability is limited to the fees paid for the relevant service.',
  },
  {
    heading: "Termination",
    text: "Either party may terminate an engagement with written notice per the SOW. Fees for work completed up to termination remain payable.",
  },
  {
    heading: "Governing law",
    text: "These Terms are governed by the laws of Bangladesh. Disputes will be resolved in the courts of Dhaka.",
  },
  {
    heading: "Contact",
    text: "Questions about these Terms? Email contact@boldbind.com.",
  },
];

export function LegalPage({ kind }: { kind: "privacy" | "terms" }) {
  const isPrivacy = kind === "privacy";
  const sections = isPrivacy ? PRIVACY : TERMS;

  return (
    <main>
      <section className="relative overflow-hidden py-24 md:py-32">
        <div className="mesh-bg absolute inset-0 opacity-70" aria-hidden />
        <div className="container-x relative max-w-4xl">
          <Reveal>
            <span className="text-xs font-semibold tracking-[0.24em] text-brand uppercase">Legal</span>
          </Reveal>
          <Reveal delay={0.05}>
            <h1 className="mt-4 font-display text-5xl font-bold leading-[1.05] tracking-tight md:text-7xl">
              {isPrivacy ? "Privacy" : "Service"}{" "}
              <span className="text-gradient-brand">Policy.</span>
            </h1>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-8 text-lg text-ink-soft">
              Last updated: July 2026. {isPrivacy ? "This page is maintained by Bold Bind." : ""}
            </p>
          </Reveal>
        </div>
      </section>

      <section className="pb-24 md:pb-32">
        <div className="container-x max-w-3xl space-y-8">
          {sections.map((section, i) => (
            <Reveal key={i}>
              <div>
                {section.heading && (
                  <h2 className="mb-3 font-display text-2xl font-bold text-ink">{section.heading}</h2>
                )}
                <p className="leading-relaxed text-ink-soft">{section.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </main>
  );
}
