import Image from "next/image";

export function Logo() {
  return (
    <span className="group inline-flex items-center">
      <Image
        src="/images/web_logo_same.png"
        alt="Bold Bind"
        width={180}
        height={40}
        priority
        className="h-8 w-auto transition-transform duration-300 group-hover:scale-[1.02]"
      />
    </span>
  );
}
