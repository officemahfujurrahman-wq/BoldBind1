"use client";

import { ArrowRight, ArrowUpRight } from "lucide-react";
import { Reveal, Stagger, StaggerItem } from "./reveal";
import { SERVICES, SERVICE_ICONS } from "@/lib/site-data";

/* Short card copy shown on the homepage, exactly as the original. */
const SHORT_DESC: Record<string, string> = {
  "digital-marketing": "Performance ads, SEO, and social that compound growth.",
  "brand-identity": "Logos, systems, and guidelines that make brands unforgettable.",
  "creative-design": "Scroll-stopping social, UI, and motion design.",
  "business-automation": "CRM, ERP, AI, and WhatsApp workflows that scale ops.",
  "business-consultation": "Strategy, market research, and growth planning.",
  "studio-video": "Commercials, product films, drone, and photography.",
};

export function ServicesSection({ onNavigate }: { onNavigate: (path: string) => void }) {
  return (
    <section className="py-24 md:py-32">
      <div className="container-x">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <Reveal>
              <span className="text-xs font-semibold tracking-[0.24em] text-brand uppercase">Services</span>
            </Reveal>
            <Reveal delay={0.05}>
              <h2 className="mt-3 font-display text-4xl font-bold tracking-tight text-ink md:text-5xl">
                Everything you need to <span className="text-gradient-brand">build &amp; scale</span>.
              </h2>
            </Reveal>
          </div>
          <Reveal delay={0.1}>
            <a
              href="#/services"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("/services");
              }}
              className="inline-flex items-center gap-2 text-sm font-semibold text-ink hover:text-brand"
            >
              Explore all services <ArrowRight className="h-4 w-4" aria-hidden />
            </a>
          </Reveal>
        </div>

        <Stagger className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((service) => {
            const Icon = SERVICE_ICONS[service.slug];
            return (
              <StaggerItem key={service.slug} className="h-full">
                <a
                  href={`#/services/${service.slug}`}
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate(`/services/${service.slug}`);
                  }}
                  className="group relative flex h-full flex-col overflow-hidden rounded-3xl border border-border bg-card p-8 transition-all duration-500 hover:-translate-y-1 hover:border-transparent hover:shadow-[0_30px_60px_-30px_oklch(0.16_0.01_20/0.35)]"
                >
                  <div className="absolute inset-0 -z-10 bg-gradient-to-br from-brand-soft to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
                  <div className="flex items-center justify-between">
                    <span className="grid h-14 w-14 place-items-center rounded-2xl bg-ink text-white transition-colors group-hover:bg-brand">
                      {Icon && <Icon className="h-6 w-6" aria-hidden />}
                    </span>
                    <ArrowUpRight
                      className="h-5 w-5 text-ink-soft transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-brand"
                      aria-hidden
                    />
                  </div>
                  <h3 className="mt-8 text-xl font-semibold text-ink">{service.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink-soft">{SHORT_DESC[service.slug]}</p>
                  <div className="mt-6 flex items-center gap-2 text-sm font-semibold text-brand opacity-0 transition-opacity group-hover:opacity-100">
                    Learn more about {service.title}{" "}
                    <ArrowRight className="h-3.5 w-3.5" aria-hidden />
                  </div>
                </a>
              </StaggerItem>
            );
          })}
        </Stagger>
      </div>
    </section>
  );
}
