"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Clock,
  Facebook,
  Instagram,
  Linkedin,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  Sparkles,
  Twitter,
  Youtube,
} from "lucide-react";
import { Reveal } from "./reveal";
import { BRAND, BUDGET_RANGES } from "@/lib/site-data";

const SOCIAL_LINKS = [
  { icon: Facebook, href: "https://www.facebook.com/boldbind", label: "Facebook" },
  { icon: Instagram, href: "https://www.instagram.com/bold_bind", label: "Instagram" },
  { icon: Linkedin, href: "https://www.linkedin.com/company/boldbind", label: "LinkedIn" },
  { icon: Youtube, href: "https://www.youtube.com/@boldbind", label: "YouTube" },
  { icon: Twitter, href: "https://twitter.com/boldbind", label: "Twitter / X" },
  { icon: MessageCircle, href: "https://wa.me/8801577301388", label: "WhatsApp" },
];

function FieldLabel({ children }: { children: React.ReactNode }) {
  return (
    <label className="text-xs font-semibold tracking-widest text-ink-soft uppercase">{children}</label>
  );
}

function Field({
  label,
  name,
  type = "text",
  required = false,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <FieldLabel>{label}</FieldLabel>
      <input
        name={name}
        type={type}
        required={required}
        className="mt-2 h-12 w-full rounded-xl border border-border bg-background px-4 text-sm outline-none focus:border-brand"
      />
    </div>
  );
}

export function ContactPage() {
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  return (
    <main>
      <section className="relative overflow-hidden py-24 md:py-32">
        <div className="mesh-bg absolute inset-0 opacity-70" aria-hidden />
        <div className="container-x relative">
          <Reveal>
            <span className="text-xs font-semibold tracking-[0.24em] text-brand uppercase">Contact</span>
          </Reveal>
          <Reveal delay={0.05}>
            <h1 className="mt-4 max-w-4xl font-display text-5xl font-bold leading-[1.05] tracking-tight md:text-7xl">
              Let&apos;s build something <span className="text-gradient-brand">bold.</span>
            </h1>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-8 max-w-2xl text-lg text-ink-soft">
              Tell us about your project. We&apos;ll get back within one business day to book your
              free 30-minute strategy call.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="pb-24 md:pb-32">
        <div className="container-x grid gap-8 lg:grid-cols-[1fr_1.2fr]">
          {/* Left column */}
          <div className="space-y-6">
            <a
              href={BRAND.calendly}
              target="_blank"
              rel="noreferrer"
              className="group flex items-center justify-between gap-4 rounded-[2rem] border border-brand bg-brand p-6 text-white transition-transform hover:-translate-y-0.5"
            >
              <div>
                <p className="text-xs tracking-widest text-white/80 uppercase">Fastest way</p>
                <p className="mt-1 font-display text-xl font-bold">Book Free Consultation</p>
                <p className="text-sm text-white/80">30-min strategy call with our team</p>
              </div>
              <span className="grid h-11 w-11 place-items-center rounded-full bg-white text-brand transition-transform group-hover:translate-x-1">
                <ArrowRight className="h-4 w-4" aria-hidden />
              </span>
            </a>

            <div className="rounded-[2rem] border border-border bg-card p-8">
              <h2 className="font-display text-2xl font-bold">Reach us directly.</h2>
              <div className="mt-6 space-y-5 text-sm">
                <a href={BRAND.phoneHref} className="flex items-start gap-4 text-ink hover:text-brand">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-brand-soft text-brand">
                    <Phone className="h-4 w-4" aria-hidden />
                  </span>
                  <span>
                    <span className="block text-xs tracking-widest text-ink-soft uppercase">Phone</span>
                    <span className="mt-1 block font-semibold">{BRAND.phone}</span>
                  </span>
                </a>
                <a href={`mailto:${BRAND.email}`} className="flex items-start gap-4 text-ink hover:text-brand">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-brand-soft text-brand">
                    <Mail className="h-4 w-4" aria-hidden />
                  </span>
                  <span>
                    <span className="block text-xs tracking-widest text-ink-soft uppercase">Email</span>
                    <span className="mt-1 block font-semibold">{BRAND.email}</span>
                  </span>
                </a>
                <div className="flex items-start gap-4 text-ink">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-brand-soft text-brand">
                    <MapPin className="h-4 w-4" aria-hidden />
                  </span>
                  <span>
                    <span className="block text-xs tracking-widest text-ink-soft uppercase">Studio</span>
                    <span className="mt-1 block leading-snug font-semibold">
                      {BRAND.addressLine1}
                      <br />
                      {BRAND.addressLine2}
                    </span>
                  </span>
                </div>
                <div className="flex items-start gap-4 text-ink">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-brand-soft text-brand">
                    <Clock className="h-4 w-4" aria-hidden />
                  </span>
                  <span>
                    <span className="block text-xs tracking-widest text-ink-soft uppercase">Hours</span>
                    <span className="mt-1 block font-semibold">{BRAND.hours}</span>
                  </span>
                </div>
              </div>

              <div className="mt-8 border-t border-border pt-6">
                <p className="text-xs font-semibold tracking-widest text-ink-soft uppercase">Follow us</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {SOCIAL_LINKS.map(({ icon: Icon, href, label }) => (
                    <a
                      key={label}
                      href={href}
                      target="_blank"
                      rel="noreferrer"
                      aria-label={label}
                      className="grid h-10 w-10 place-items-center rounded-full border border-border text-ink-soft transition-all hover:border-brand hover:bg-brand hover:text-white"
                    >
                      <Icon className="h-4 w-4" aria-hidden />
                    </a>
                  ))}
                </div>
              </div>
            </div>

            <div className="overflow-hidden rounded-[2rem] border border-border">
              <iframe
                title="Bold Bind location"
                src="https://www.google.com/maps?q=Mirpur,+Dhaka,+Bangladesh&output=embed"
                className="h-72 w-full"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>

          {/* Form */}
          <motion.form
            onSubmit={async (e) => {
              e.preventDefault();
              if (sending) return;
              const form = e.currentTarget;
              const fd = new FormData(form);
              const payload = {
                name: String(fd.get("name") || "").trim(),
                company: String(fd.get("company") || "").trim(),
                email: String(fd.get("email") || "").trim(),
                phone: String(fd.get("phone") || "").trim(),
                service: String(fd.get("service") || "").trim(),
                budget: String(fd.get("budget") || "").trim(),
                message: String(fd.get("message") || "").trim(),
              };
              setSending(true);
              setError(null);
              try {
                const res = await fetch("/api/contact", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify(payload),
                });
                if (!res.ok) {
                  const json = (await res.json().catch(() => null)) as {
                    error?: string;
                  } | null;
                  throw new Error(json?.error || "Something went wrong. Please try again.");
                }
                setSent(true);
                form.reset();
              } catch (err) {
                setError(
                  err instanceof Error
                    ? err.message
                    : "Something went wrong. Please try again."
                );
              } finally {
                setSending(false);
              }
            }}
            className="rounded-[2rem] border border-border bg-card p-8 md:p-10"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-flex items-center gap-2 rounded-full bg-brand-soft px-3 py-1 text-xs font-semibold text-brand">
              <Sparkles className="h-3.5 w-3.5" aria-hidden /> Free 30-min consultation
            </span>
            <h2 className="mt-4 font-display text-3xl font-bold">Tell us about your project.</h2>
            {sent ? (
              <div className="mt-8 rounded-2xl border border-brand bg-brand-soft p-6 text-center">
                <p className="font-semibold text-ink">
                  Thanks — we&apos;ll be in touch within one business day.
                </p>
              </div>
            ) : (
              <>
              {error && (
                <p className="mt-6 rounded-xl border border-brand bg-brand-soft px-4 py-3 text-sm font-medium text-brand">
                  {error}
                </p>
              )}
              <div className="mt-8 grid gap-4 sm:grid-cols-2">
                <Field label="Name" name="name" required />
                <Field label="Company" name="company" />
                <Field label="Email" name="email" type="email" required />
                <Field label="Phone" name="phone" />
                <div className="sm:col-span-2">
                  <FieldLabel>Service</FieldLabel>
                  <select
                    name="service"
                    className="mt-2 h-12 w-full rounded-xl border border-border bg-background px-4 text-sm outline-none focus:border-brand"
                    defaultValue=""
                    aria-label="Select a service"
                  >
                    <option value="" disabled>
                      Select a service
                    </option>
                    <option>Digital Marketing</option>
                    <option>Brand Identity</option>
                    <option>Creative Design</option>
                    <option>Business Automation</option>
                    <option>Business Consultation</option>
                    <option>Studio &amp; Video Production</option>
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <FieldLabel>Budget</FieldLabel>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {BUDGET_RANGES.map((range) => (
                      <label key={range} className="cursor-pointer">
                        <input type="radio" name="budget" value={range} className="peer sr-only" />
                        <span className="rounded-full border border-border px-4 py-2 text-sm text-ink-soft transition-all peer-checked:border-ink peer-checked:bg-ink peer-checked:text-white">
                          {range}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
                <div className="sm:col-span-2">
                  <FieldLabel>Message</FieldLabel>
                  <textarea
                    name="message"
                    rows={5}
                    required
                    placeholder="Tell us about your goals, timeline, and anything else."
                    className="mt-2 w-full rounded-xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-brand"
                  />
                </div>
                <button
                  type="submit"
                  disabled={sending}
                  className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-brand px-6 py-4 text-sm font-semibold text-white shadow-[0_18px_40px_-14px_oklch(0.595_0.238_27.2/0.7)] transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-70 sm:col-span-2"
                >
                  {sending ? "Sending…" : "Send Message"}
                  {!sending && <ArrowRight className="h-4 w-4" aria-hidden />}
                </button>
              </div>
              </>
            )}
          </motion.form>
        </div>
      </section>
    </main>
  );
}
