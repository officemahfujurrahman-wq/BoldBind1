"use client";

import { ArrowRight, ArrowUpRight, Calendar, Clock } from "lucide-react";
import { Reveal } from "./reveal";
import { BLOG_POSTS } from "@/lib/site-data";

export function BlogDetailPage({ slug }: { slug: string }) {
  const post = BLOG_POSTS.find((p) => p.slug === slug);
  if (!post) {
    return (
      <main className="container-x py-40 text-center">
        <h1 className="font-display text-4xl font-bold">Article not found</h1>
        <a href="#/blog" className="mt-6 inline-block text-brand hover:underline">
          Back to blog
        </a>
      </main>
    );
  }

  const related = BLOG_POSTS.filter((p) => p.slug !== post.slug && p.cat === post.cat).slice(0, 3);

  return (
    <main>
      {/* Hero */}
      <section className="relative overflow-hidden py-20 md:py-28">
        <div className="mesh-bg absolute inset-0 opacity-70" aria-hidden />
        <div className="container-x relative max-w-4xl">
          <Reveal>
            <a href="#/blog" className="inline-flex items-center gap-2 text-sm text-ink-soft hover:text-brand">
              <ArrowUpRight className="h-3.5 w-3.5 -rotate-90" aria-hidden /> Back to blog
            </a>
          </Reveal>
          <Reveal delay={0.05}>
            <span className="mt-8 inline-flex rounded-full bg-brand-soft px-3 py-1 text-xs font-semibold text-brand">
              {post.cat}
            </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h1 className="mt-4 font-display text-4xl font-bold leading-[1.1] tracking-tight md:text-6xl">
              {post.title}
            </h1>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="mt-6 flex flex-wrap items-center gap-4 text-sm text-ink-soft">
              <span className="inline-flex items-center gap-2">
                <Calendar className="h-4 w-4" aria-hidden /> {post.date}
              </span>
              <span className="inline-flex items-center gap-2">
                <Clock className="h-4 w-4" aria-hidden /> {post.read} read
              </span>
              <span>By {post.author}</span>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Cover */}
      <section className="pb-12">
        <div className="container-x max-w-5xl">
          <Reveal>
            <div className={`relative aspect-[16/8] overflow-hidden rounded-[2rem] bg-gradient-to-br ${post.tone}`}>
              <div className="grid-bg absolute inset-0 opacity-15" aria-hidden />
              <div className="absolute inset-0 grid place-items-center font-display text-4xl font-bold text-white/40">
                {post.cat}
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Body */}
      <section className="pb-24">
        <div className="container-x mx-auto max-w-3xl space-y-7 text-lg leading-relaxed text-ink-soft">
          <Reveal>
            <p className="text-xl text-ink">{post.excerpt}</p>
          </Reveal>
          {post.body.map((block, i) => (
            <Reveal key={i}>
              {block.type === "p" && <p>{block.text}</p>}
              {block.type === "h2" && (
                <h2 className="pt-4 font-display text-3xl font-bold text-ink">{block.text}</h2>
              )}
              {block.type === "quote" && (
                <blockquote className="border-l-4 border-brand pl-6 font-display text-2xl font-semibold text-ink">
                  &ldquo;{block.text}&rdquo;
                  {block.cite && <cite className="mt-3 block text-sm font-normal text-ink-soft">{block.cite}</cite>}
                </blockquote>
              )}
              {block.type === "list" && (
                <ul className="space-y-3 pl-1">
                  {block.items?.map((item) => (
                    <li key={item} className="flex gap-3">
                      <span className="mt-2.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand" aria-hidden />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              )}
            </Reveal>
          ))}
          <Reveal>
            <a
              href="https://calendly.com/contact-boldbind/30min"
              target="_blank"
              rel="noreferrer"
              className="mt-4 inline-flex items-center gap-2 rounded-full bg-brand px-6 py-3.5 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5"
            >
              Book Free Consultation <ArrowRight className="h-4 w-4" aria-hidden />
            </a>
          </Reveal>
        </div>
      </section>

      {/* Related */}
      {related.length > 0 && (
        <section className="bg-surface py-24">
          <div className="container-x">
            <Reveal>
              <h2 className="font-display text-3xl font-bold tracking-tight md:text-4xl">Keep reading.</h2>
            </Reveal>
            <div className="mt-10 grid gap-6 md:grid-cols-3">
              {related.map((p) => (
                <Reveal key={p.slug}>
                  <a
                    href={`#/blog/${p.slug}`}
                    className="group flex h-full flex-col overflow-hidden rounded-3xl border border-border bg-card transition-all hover:-translate-y-1 hover:shadow-xl"
                  >
                    <div className={`relative aspect-[16/10] overflow-hidden bg-gradient-to-br ${p.tone}`}>
                      <div className="grid-bg absolute inset-0 opacity-15" aria-hidden />
                      <div className="absolute inset-0 grid place-items-center font-display text-3xl font-bold text-white/40">
                        {p.cat}
                      </div>
                    </div>
                    <div className="flex flex-1 flex-col p-6">
                      <span className="text-xs font-semibold text-brand">{p.cat}</span>
                      <h3 className="mt-2 font-display text-lg font-semibold leading-snug group-hover:text-brand">
                        {p.title}
                      </h3>
                    </div>
                  </a>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}
    </main>
  );
}
