"use client";

import { ArrowRight, Briefcase, Clock, Sparkles } from "lucide-react";
import { Reveal, Stagger, StaggerItem } from "./reveal";
import { OPEN_ROLES, PERKS } from "@/lib/site-data";

export function CareersPage() {
  return (
    <main>
      <section className="relative overflow-hidden py-24 md:py-32">
        <div className="mesh-bg absolute inset-0 opacity-70" aria-hidden />
        <div className="container-x relative">
          <Reveal>
            <span className="text-xs font-semibold tracking-[0.24em] text-brand uppercase">Careers</span>
          </Reveal>
          <Reveal delay={0.05}>
            <h1 className="mt-4 max-w-4xl font-display text-5xl font-bold leading-[1.05] tracking-tight md:text-7xl">
              Build bold work with <span className="text-gradient-brand">us.</span>
            </h1>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-8 max-w-2xl text-lg text-ink-soft">
              We&apos;re always looking for curious, ambitious people who care about craft and
              outcomes.
            </p>
          </Reveal>
        </div>
      </section>

      {/* Perks */}
      <section className="pb-16">
        <div className="container-x">
          <Reveal>
            <h2 className="font-display text-3xl font-bold md:text-4xl">Perks &amp; culture</h2>
          </Reveal>
          <Stagger className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {PERKS.map((perk) => (
              <StaggerItem key={perk}>
                <div className="flex items-center gap-3 rounded-2xl border border-border bg-card p-5">
                  <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-soft text-brand">
                    <Sparkles className="h-4 w-4" aria-hidden />
                  </span>
                  <p className="text-sm font-medium">{perk}</p>
                </div>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      {/* Open roles */}
      <section className="pb-24 md:pb-32">
        <div className="container-x">
          <Reveal>
            <h2 className="font-display text-3xl font-bold md:text-4xl">Open roles</h2>
          </Reveal>
          <Stagger className="mt-8 grid gap-3">
            {OPEN_ROLES.map((role) => (
              <StaggerItem key={role.title}>
                <a
                  href="mailto:careers@boldbind.com"
                  className="group flex flex-col justify-between gap-4 rounded-3xl border border-border bg-card p-6 transition-all hover:-translate-y-0.5 hover:border-brand hover:shadow-xl sm:flex-row sm:items-center"
                >
                  <div>
                    <h3 className="font-display text-xl font-semibold group-hover:text-brand">{role.title}</h3>
                    <div className="mt-2 flex flex-wrap items-center gap-4 text-sm text-ink-soft">
                      <span className="inline-flex items-center gap-1.5">
                        <Clock className="h-3.5 w-3.5" aria-hidden /> {role.type}
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <Briefcase className="h-3.5 w-3.5" aria-hidden /> {role.location}
                      </span>
                    </div>
                  </div>
                  <span className="inline-flex items-center gap-2 text-sm font-semibold text-ink">
                    Apply <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
                  </span>
                </a>
              </StaggerItem>
            ))}
          </Stagger>
          <Reveal>
            <div className="mt-14 rounded-3xl border border-border bg-card p-8 text-center">
              <p className="text-ink-soft">Don&apos;t see your role? We&apos;d still love to hear from you.</p>
              <a
                href="mailto:careers@boldbind.com"
                className="mt-4 inline-flex items-center gap-2 rounded-full bg-brand px-6 py-3 text-sm font-semibold text-white"
              >
                careers@boldbind.com <ArrowRight className="h-4 w-4" aria-hidden />
              </a>
            </div>
          </Reveal>
        </div>
      </section>
    </main>
  );
}
