"use client";

import { ArrowRight, Sparkles } from "lucide-react";
import { Reveal } from "./reveal";
import { BRAND } from "@/lib/site-data";

export function CtaSection() {
  return (
    <section className="py-24 md:py-32">
      <div className="container-x">
        <Reveal>
          <div className="relative overflow-hidden rounded-[2rem] bg-ink px-8 py-20 text-center text-white md:px-16 md:py-28">
            <div className="pointer-events-none absolute -top-24 left-1/2 h-96 w-96 -translate-x-1/2 rounded-full bg-brand/40 blur-3xl" aria-hidden />
            <div className="grid-bg pointer-events-none absolute inset-0 opacity-[0.06]" aria-hidden />
            <div className="relative">
              <span className="inline-flex items-center gap-2 rounded-full border border-white/15 px-4 py-1.5 text-xs font-medium text-white/80">
                <Sparkles className="h-3.5 w-3.5 text-brand" aria-hidden /> Let&apos;s build something bold
              </span>
              <h2 className="mx-auto mt-6 max-w-3xl font-display text-4xl font-bold leading-tight tracking-tight md:text-6xl">
                Ready to grow your brand <span className="text-gradient-brand">digitally?</span>
              </h2>
              <p className="mx-auto mt-6 max-w-xl text-white/70">
                Book a free 30-minute consultation. We&apos;ll audit your current setup and map out
                the fastest path to growth — no strings attached.
              </p>
              <div className="mt-10 flex flex-wrap justify-center gap-3">
                <a
                  href={BRAND.calendly}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 rounded-full bg-brand px-7 py-4 text-sm font-semibold text-white shadow-[0_18px_40px_-14px_oklch(0.595_0.238_27.2/0.7)] transition-transform hover:-translate-y-0.5"
                >
                  Book Free Consultation <ArrowRight className="h-4 w-4" aria-hidden />
                </a>
                <a
                  href={`mailto:${BRAND.email}`}
                  className="inline-flex items-center gap-2 rounded-full border border-white/20 px-7 py-4 text-sm font-semibold text-white hover:border-white"
                >
                  {BRAND.email}
                </a>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
