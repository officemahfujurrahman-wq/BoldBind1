"use client";

import { useEffect, useState } from "react";
import { motion, useScroll, useSpring } from "framer-motion";
import { ArrowRight, Menu, X } from "lucide-react";
import { Logo } from "./logo";
import { BRAND, NAV_ITEMS, type PageId } from "@/lib/site-data";

export function Header({
  current,
  onNavigate,
}: {
  current: PageId;
  onNavigate: (path: string) => void;
}) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 24, mass: 0.2 });

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      {/* Scroll progress bar */}
      <motion.div
        style={{ scaleX }}
        className="fixed inset-x-0 top-0 z-[60] h-0.5 origin-left bg-brand"
      />
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
          scrolled
            ? "border-b border-border/60 bg-background/70 backdrop-blur-xl"
            : "border-b border-transparent bg-transparent"
        }`}
      >
        <div className="container-x flex h-16 items-center justify-between md:h-20">
          <a
            href="#/"
            onClick={(e) => {
              e.preventDefault();
              onNavigate("/");
            }}
            aria-label="Bold Bind — home"
          >
            <Logo />
          </a>

          <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
            {NAV_ITEMS.map((item) => (
              <a
                key={item.id}
                href={`#/${item.id === "home" ? "" : item.id}`}
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate(item.id === "home" ? "/" : `/${item.id}`);
                }}
                aria-current={current === item.id ? "page" : undefined}
                className={`relative px-4 py-2 text-sm font-medium text-ink/75 transition-colors hover:text-ink ${
                  current === item.id ? "text-ink" : ""
                }`}
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <a
              href={BRAND.calendly}
              target="_blank"
              rel="noreferrer"
              className="hidden items-center gap-2 rounded-full bg-ink px-5 py-2.5 text-sm font-semibold text-white transition-all hover:bg-brand hover:shadow-[0_10px_30px_-10px_oklch(0.595_0.238_27.2/0.7)] md:inline-flex"
            >
              Book a Free Consultation
              <ArrowRight className="h-4 w-4" aria-hidden />
            </a>
            <button
              aria-label="Toggle menu"
              aria-expanded={open}
              onClick={() => setOpen((v) => !v)}
              className="grid h-11 w-11 place-items-center rounded-full border border-border bg-background/80 lg:hidden"
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {open && (
          <div className="border-t border-border bg-background/95 backdrop-blur-xl lg:hidden">
            <div className="container-x flex flex-col gap-1 py-4">
              {NAV_ITEMS.map((item) => (
                <a
                  key={item.id}
                  href={`#/${item.id === "home" ? "" : item.id}`}
                  onClick={(e) => {
                    e.preventDefault();
                    setOpen(false);
                    onNavigate(item.id === "home" ? "/" : `/${item.id}`);
                  }}
                  className="rounded-lg px-3 py-3 text-base font-medium text-ink/80 hover:bg-muted"
                >
                  {item.label}
                </a>
              ))}
              <a
                href={BRAND.calendly}
                target="_blank"
                rel="noreferrer"
                onClick={() => setOpen(false)}
                className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-ink px-5 py-3 text-sm font-semibold text-white"
              >
                Book a Free Consultation <ArrowRight className="h-4 w-4" aria-hidden />
              </a>
            </div>
          </div>
        )}
      </header>
    </>
  );
}
