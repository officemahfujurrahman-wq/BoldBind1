"use client";

import { ArrowRight, ArrowUpRight } from "lucide-react";
import { Reveal, Stagger, StaggerItem } from "./reveal";
import { BRAND, SERVICES, SERVICE_ICONS } from "@/lib/site-data";

export function ServicesPage() {
  return (
    <main>
      <section className="relative overflow-hidden py-24 md:py-32">
        <div className="mesh-bg absolute inset-0 opacity-70" aria-hidden />
        <div className="container-x relative">
          <Reveal>
            <span className="text-xs font-semibold tracking-[0.24em] text-brand uppercase">Services</span>
          </Reveal>
          <Reveal delay={0.05}>
            <h1 className="mt-4 max-w-4xl font-display text-5xl font-bold leading-[1.05] tracking-tight md:text-7xl">
              Six disciplines. <span className="text-gradient-brand">One partner.</span>
            </h1>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-8 max-w-2xl text-lg text-ink-soft">
              From brand-building to lead-generating campaigns and full-stack automations —
              everything you need to grow a modern business, delivered by one team.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="pb-24 md:pb-32">
        <div className="container-x">
          <Reveal>
            <h2 className="mb-10 font-display text-3xl font-bold tracking-tight md:text-4xl">
              Our Core Services
            </h2>
          </Reveal>
          <Stagger className="grid gap-5 md:grid-cols-2">
            {SERVICES.map((service) => {
              const Icon = SERVICE_ICONS[service.slug];
              return (
                <StaggerItem key={service.slug}>
                  <a
                    href={`#/services/${service.slug}`}
                    className="group relative flex h-full flex-col overflow-hidden rounded-3xl border border-border bg-card p-10 transition-all duration-500 hover:-translate-y-1 hover:border-transparent hover:shadow-[0_30px_60px_-30px_oklch(0.16_0.01_20/0.35)]"
                  >
                    <div className="absolute inset-0 -z-10 bg-gradient-to-br from-brand-soft to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
                    <div className="flex items-center justify-between">
                      <span className="grid h-14 w-14 place-items-center rounded-2xl bg-ink text-white transition-colors group-hover:bg-brand">
                        {Icon && <Icon className="h-6 w-6" aria-hidden />}
                      </span>
                      <ArrowUpRight
                        className="h-5 w-5 text-ink-soft transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-brand"
                        aria-hidden
                      />
                    </div>
                    <p className="mt-8 text-xs font-semibold tracking-[0.24em] text-brand uppercase">
                      {service.tagline}
                    </p>
                    <h3 className="mt-3 font-display text-3xl font-bold tracking-tight text-ink">
                      {service.title}
                    </h3>
                    <p className="mt-4 text-ink-soft">{service.desc}</p>
                    <ul className="mt-6 flex flex-wrap gap-2">
                      {service.features.map((feature) => (
                        <li
                          key={feature}
                          className="rounded-full border border-border bg-background px-3 py-1 text-xs text-ink-soft"
                        >
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <div className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-brand opacity-0 transition-opacity group-hover:opacity-100">
                      Learn more about {service.title}{" "}
                      <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" aria-hidden />
                    </div>
                  </a>
                </StaggerItem>
              );
            })}
          </Stagger>
        </div>
      </section>

      <section className="pb-24 md:pb-32">
        <div className="container-x">
          <Reveal>
            <div className="flex flex-col items-start justify-between gap-6 rounded-[2rem] bg-ink p-10 text-white md:flex-row md:items-center md:p-14">
              <div>
                <h3 className="font-display text-3xl font-bold md:text-4xl">Not sure where to start?</h3>
                <p className="mt-2 text-white/70">
                  Get a free 30-minute strategy call with our team.
                </p>
              </div>
              <a
                href={BRAND.calendly}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 rounded-full bg-brand px-6 py-3.5 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5"
              >
                Book Free Consultation <ArrowRight className="h-4 w-4" aria-hidden />
              </a>
            </div>
          </Reveal>
        </div>
      </section>
    </main>
  );
}
