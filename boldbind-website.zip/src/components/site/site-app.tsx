"use client";

import { useEffect, useSyncExternalStore } from "react";
import { Header } from "./header";
import { Footer } from "./footer";
import { HomePage } from "./home-page";
import { AboutPage } from "./about-page";
import { TeamPage } from "./team-page";
import { CareersPage } from "./careers-page";
import { ServicesPage } from "./services-page";
import { ServiceDetailPage } from "./service-detail-page";
import { PortfolioPage } from "./portfolio-page";
import { PortfolioDetailPage } from "./portfolio-detail-page";
import { BlogPage } from "./blog-page";
import { BlogDetailPage } from "./blog-detail-page";
import { ContactPage } from "./contact-page";
import { LegalPage } from "./legal-page";
import { BLOG_POSTS, PORTFOLIO_PROJECTS, SERVICES, type PageId } from "@/lib/site-data";

/* ------------------------------ hash router ------------------------------- */

function pathFromHash(): string {
  if (typeof window === "undefined") return "/";
  const raw = window.location.hash.replace(/^#\/?/, "");
  const path = `/${raw}`.replace(/\/+$/, "") || "/";
  return path;
}

function subscribe(onChange: () => void) {
  window.addEventListener("hashchange", onChange);
  return () => window.removeEventListener("hashchange", onChange);
}

function getSnapshot(): string {
  return pathFromHash();
}

function getServerSnapshot(): string {
  return "/";
}

/* ------------------------------ page metadata ----------------------------- */

function titleFor(path: string): string {
  if (path === "/" ) return "Bold Bind — Creative & Digital Agency";
  if (path === "/about") return "About — Bold Bind";
  if (path === "/team") return "Team — Bold Bind";
  if (path === "/careers") return "Careers — Bold Bind";
  if (path === "/services") return "Services — Bold Bind";
  if (path === "/portfolio") return "Portfolio — Bold Bind Case Studies";
  if (path === "/blog") return "Blog — Bold Bind Insights";
  if (path === "/contact") return "Contact — Bold Bind";
  if (path === "/privacy") return "Privacy Policy — Bold Bind";
  if (path === "/terms") return "Terms of Service — Bold Bind";
  const [, root, slug] = path.split("/");
  if (root === "services") {
    const s = SERVICES.find((x) => x.slug === slug);
    if (s) return `${s.title} — Bold Bind`;
  }
  if (root === "portfolio") {
    const p = PORTFOLIO_PROJECTS.find((x) => x.slug === slug);
    if (p) return `${p.title} — Bold Bind Case Study`;
  }
  if (root === "blog") {
    const b = BLOG_POSTS.find((x) => x.slug === slug);
    if (b) return `${b.title} — Bold Bind`;
  }
  return "Bold Bind — Creative & Digital Agency";
}

function currentPageId(path: string): PageId {
  const root = path.split("/")[1];
  const known: PageId[] = ["home", "about", "services", "portfolio", "blog", "contact"];
  if (known.includes(root as PageId)) return root as PageId;
  return "home";
}

/* --------------------------------- the app -------------------------------- */

export function SiteApp() {
  const path = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  const navigate = (next: string) => {
    const target = next === "/" ? "#/" : `#${next}`;
    if (pathFromHash() === next) {
      window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
      return;
    }
    window.location.hash = target;
  };

  useEffect(() => {
    document.title = titleFor(path);
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  }, [path]);

  const pageId = currentPageId(path);
  const [, root, slug] = path.split("/");

  let content: React.ReactNode;
  switch (root) {
    case "about":
      content = <AboutPage onNavigate={navigate} />;
      break;
    case "team":
      content = <TeamPage />;
      break;
    case "careers":
      content = <CareersPage />;
      break;
    case "services":
      content = slug ? <ServiceDetailPage slug={slug} /> : <ServicesPage />;
      break;
    case "portfolio":
      content = slug ? <PortfolioDetailPage slug={slug} /> : <PortfolioPage onNavigate={navigate} />;
      break;
    case "blog":
      content = slug ? <BlogDetailPage slug={slug} /> : <BlogPage />;
      break;
    case "contact":
      content = <ContactPage />;
      break;
    case "privacy":
      content = <LegalPage kind="privacy" />;
      break;
    case "terms":
      content = <LegalPage kind="terms" />;
      break;
    default:
      content = <HomePage onNavigate={navigate} />;
  }

  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[60] focus:rounded-full focus:bg-primary focus:px-4 focus:py-2 focus:text-sm focus:text-white"
      >
        Skip to main content
      </a>
      <Header current={pageId} onNavigate={navigate} />
      <div id="main-content" className="flex-1 pt-16 md:pt-20">
        {content}
      </div>
      <Footer onNavigate={navigate} />
    </div>
  );
}
