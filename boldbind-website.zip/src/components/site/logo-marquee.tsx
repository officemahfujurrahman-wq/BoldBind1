"use client";

import { CLIENT_LOGOS } from "@/lib/site-data";

export function LogoMarquee() {
  const doubled = [...CLIENT_LOGOS, ...CLIENT_LOGOS];
  return (
    <section className="border-y border-border bg-surface py-10">
      <div className="container-x">
        <p className="text-center text-xs font-medium uppercase tracking-[0.24em] text-ink-soft">
          Trusted by teams at
        </p>
        <div
          className="relative mt-6 overflow-hidden"
          style={{
            maskImage: "linear-gradient(to right, transparent, black 12%, black 88%, transparent)",
            WebkitMaskImage: "linear-gradient(to right, transparent, black 12%, black 88%, transparent)",
          }}
        >
          <div className="animate-marquee flex w-max gap-16">
            {doubled.map((name, i) => (
              <span
                key={`${name}-${i}`}
                className="font-display text-xl font-semibold tracking-tight text-ink/40 whitespace-nowrap transition-colors hover:text-ink"
              >
                {name}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
