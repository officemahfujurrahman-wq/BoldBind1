"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight, Quote, Star } from "lucide-react";
import { Reveal } from "./reveal";
import { TESTIMONIALS } from "@/lib/site-data";

export function TestimonialsSection() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setIndex((i) => (i + 1) % TESTIMONIALS.length), 5500);
    return () => clearInterval(id);
  }, []);

  const prev = () => setIndex((i) => (i + TESTIMONIALS.length - 1) % TESTIMONIALS.length);
  const next = () => setIndex((i) => (i + 1) % TESTIMONIALS.length);
  const t = TESTIMONIALS[index];

  return (
    <section className="py-24 md:py-32">
      <div className="container-x">
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <span className="text-xs font-semibold tracking-[0.24em] text-brand uppercase">
              Testimonials
            </span>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="mt-3 font-display text-4xl font-bold tracking-tight md:text-5xl">
              What clients say.
            </h2>
          </Reveal>
        </div>

        <Reveal delay={0.1}>
          <div className="relative mx-auto mt-14 max-w-3xl">
            <div className="relative overflow-hidden rounded-3xl border border-border bg-card p-10 md:p-14">
              <Quote className="absolute -top-6 left-10 h-14 w-14 fill-brand text-brand" aria-hidden />
              <div className="relative min-h-[280px] md:min-h-[240px]">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: 60 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -60 }}
                    transition={{ duration: 0.5, ease: "easeOut" }}
                  >
                    <div className="flex items-center gap-1 text-brand" aria-label={`${t.rating} star rating`}>
                      {Array.from({ length: t.rating }).map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-current" aria-hidden />
                      ))}
                    </div>
                    <p className="mt-6 font-display text-2xl leading-snug text-ink md:text-3xl">
                      &ldquo;{t.quote}&rdquo;
                    </p>
                    <div className="mt-8 flex items-center gap-4">
                      <span className="grid h-12 w-12 place-items-center rounded-full bg-brand text-lg font-bold text-white">
                        {t.name.charAt(0)}
                      </span>
                      <div>
                        <p className="font-semibold text-ink">{t.name}</p>
                        <p className="text-sm text-ink-soft">{t.role}</p>
                      </div>
                    </div>
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between">
              <button
                onClick={prev}
                aria-label="Previous"
                className="grid h-11 w-11 place-items-center rounded-full border border-border bg-background text-ink transition-all hover:border-brand hover:bg-brand hover:text-white"
              >
                <ChevronLeft className="h-4 w-4" aria-hidden />
              </button>
              <div className="flex gap-2">
                {TESTIMONIALS.map((item, i) => (
                  <button
                    key={item.name}
                    onClick={() => setIndex(i)}
                    aria-label={`Testimonial ${i + 1}`}
                    className={`h-2 rounded-full transition-all ${
                      i === index ? "w-8 bg-brand" : "w-2 bg-ink/15"
                    }`}
                  />
                ))}
              </div>
              <button
                onClick={next}
                aria-label="Next"
                className="grid h-11 w-11 place-items-center rounded-full border border-border bg-background text-ink transition-all hover:border-brand hover:bg-brand hover:text-white"
              >
                <ChevronRight className="h-4 w-4" aria-hidden />
              </button>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
