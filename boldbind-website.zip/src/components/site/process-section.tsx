"use client";

import { useRef } from "react";
import { motion, useScroll, useSpring } from "framer-motion";
import { Reveal } from "./reveal";
import { PROCESS_STEPS } from "@/lib/site-data";

export function ProcessSection() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start 70%", "end 40%"],
  });
  const scaleY = useSpring(scrollYProgress, { stiffness: 80, damping: 20 });

  return (
    <section className="relative overflow-hidden py-24 md:py-32">
      <div className="pointer-events-none absolute -left-24 top-24 h-72 w-72 rounded-full bg-brand/10 blur-3xl" aria-hidden />
      <div className="pointer-events-none absolute -right-24 bottom-24 h-80 w-80 rounded-full bg-brand/10 blur-3xl" aria-hidden />
      <div
        className="pointer-events-none absolute inset-0 -z-10 opacity-[0.04]"
        aria-hidden
        style={{
          backgroundImage:
            "linear-gradient(to right, currentColor 1px, transparent 1px), linear-gradient(to bottom, currentColor 1px, transparent 1px)",
          backgroundSize: "56px 56px",
        }}
      />

      <div className="container-x relative">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <span className="text-xs font-semibold tracking-[0.24em] text-brand uppercase">
              Our Process
            </span>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="mt-3 font-display text-4xl font-bold tracking-tight md:text-5xl">
              Five steps from idea to <span className="text-gradient-brand">real growth</span>.
            </h2>
          </Reveal>
        </div>

        <div ref={ref} className="relative mt-16">
          {/* base line */}
          <div
            className="pointer-events-none absolute top-0 left-6 h-full w-px bg-border lg:left-1/2 lg:-translate-x-1/2"
            aria-hidden
          />
          {/* animated progress line */}
          <motion.div
            className="pointer-events-none absolute top-0 left-6 h-full w-[2px] bg-gradient-to-b from-brand via-brand to-brand/40 lg:left-1/2 lg:-translate-x-1/2"
            style={{ transformOrigin: "top", scaleY }}
            aria-hidden
          />
          {/* leading dot */}
          <div className="pointer-events-none absolute top-0 left-6 z-10 -translate-x-1/2 lg:left-1/2" aria-hidden>
            <span className="relative block h-3 w-3 rounded-full bg-brand shadow-[0_0_24px_6px_oklch(0.595_0.238_27.2/0.6)]">
              <span className="absolute inset-0 animate-ping rounded-full bg-brand/70" />
            </span>
          </div>

          <div className="space-y-10 lg:space-y-16">
            {PROCESS_STEPS.map((step, i) => {
              const Icon = step.icon;
              const odd = i % 2 === 0;
              const num = String(i + 1).padStart(2, "0");
              return (
                <motion.div
                  key={step.title}
                  initial={{ opacity: 0, x: odd ? -30 : 30, y: 40 }}
                  whileInView={{ opacity: 1, x: 0, y: 0 }}
                  viewport={{ once: true, margin: "-80px" }}
                  transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
                  className="relative grid gap-6 pl-16 lg:grid-cols-2 lg:gap-16 lg:pl-0"
                >
                  {/* node dot */}
                  <div className="absolute top-8 left-6 z-10 -translate-x-1/2 lg:left-1/2" aria-hidden>
                    <span className="relative grid h-5 w-5 place-items-center rounded-full bg-brand shadow-[0_0_0_6px_oklch(0.98_0_0),0_0_20px_oklch(0.595_0.238_27.2/0.6)]">
                      <span className="absolute inset-0 animate-ping rounded-full bg-brand/50" />
                    </span>
                  </div>

                  <div className={odd ? "lg:col-start-1 lg:pr-16 lg:text-right" : "lg:col-start-2 lg:pl-16"}>
                    <div className="group relative overflow-hidden rounded-3xl border border-border bg-card p-8 shadow-[0_10px_30px_-20px_rgba(0,0,0,0.2)] transition-shadow hover:shadow-[0_30px_60px_-30px_oklch(0.595_0.238_27.2/0.35)]">
                      <div className="pointer-events-none absolute inset-0 -z-10 bg-gradient-to-br from-brand-soft to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
                      <div
                        className={`flex items-center gap-4 ${odd ? "lg:flex-row-reverse" : ""}`}
                      >
                        <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-brand-soft text-brand transition-colors group-hover:bg-brand group-hover:text-white">
                          <Icon className="h-5 w-5" aria-hidden />
                        </span>
                        <span className="font-display text-5xl font-bold text-ink/10 transition-colors group-hover:text-brand/30">
                          {num}
                        </span>
                      </div>
                      <h3 className="mt-6 font-display text-2xl font-semibold">{step.title}</h3>
                      <p className="mt-2 text-sm text-ink-soft">{step.desc}</p>
                      <div
                        className={`mt-6 h-px w-16 bg-gradient-to-r from-brand to-transparent ${
                          odd ? "lg:ml-auto" : ""
                        }`}
                        style={{ transformOrigin: odd ? "right" : "left" }}
                        aria-hidden
                      />
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
