# Bold Bind — Deploy Guide (boldbind.com)

Site: Bold Bind agency website (Next.js 16 + TypeScript + Tailwind + Prisma/SQLite)

---

## Option A — Vercel (FREE, recommended) ⭐

### Step 1: Upload code to GitHub (free)
1. Unzip `boldbind-website.zip` on your computer.
2. Go to https://github.com → Sign up / Log in.
3. Click **New repository** → name it `boldbind-site` → **Private** → Create.
4. Click **"uploading an existing file"** link → drag & drop ALL files/folders from the unzipped folder → **Commit changes**.

### Step 2: Deploy on Vercel (free)
1. Go to https://vercel.com → **Sign up with GitHub**.
2. Click **Add New... → Project** → select `boldbind-site` repo → **Import**.
3. Framework Preset: **Next.js** (auto-detected, leave everything default).
4. Open **Environment Variables** → add:
   - Name: `DATABASE_URL`
   - Value: `file:/tmp/custom.db`
5. Click **Deploy** → wait 2–3 minutes → you get a live URL like `boldbind-site.vercel.app`.

### Step 3: Connect your domain boldbind.com
1. In Vercel → your project → **Settings → Domains**.
2. Type `boldbind.com` → **Add**. Also add `www.boldbind.com`.
3. Vercel will show you DNS records. Now go to your **domain registrar** website
   (where you bought boldbind.com — e.g. Namecheap / GoDaddy / Hostinger):
   - Open **DNS / Nameserver settings** for boldbind.com
   - Add these records:

   | Type  | Host/Name | Value                | TTL     |
   |-------|-----------|----------------------|---------|
   | A     | @         | 76.76.21.21          | Auto    |
   | CNAME | www       | cname.vercel-dns.com | Auto    |

   - If the registrar asks for **Nameservers** instead: choose
     **Custom DNS → ns1.vercel-dns.com / ns2.vercel-dns.com**.
4. Save. DNS propagation: 10 minutes – 24 hours (usually ~30 min).
5. Done ✅ — **https://boldbind.com** is live with free SSL (https padlock).

---

## Option B — Netlify (free)
Same as Option A, but: https://netlify.com → import from GitHub →
Build command: `npm run build` → Publish directory: `.next`.
DNS: Add domain in Netlify → point nameservers to Netlify's (shown in dashboard).

---

## Option C — cPanel / Traditional hosting
This project needs Node.js runtime (API routes + database).
On cPanel use **"Setup Node.js App"** (Node 20+):
1. Upload & extract zip → run `npm install`.
2. Run `npx prisma db push` (creates the SQLite database).
3. Start command: `npm run start` → point domain in cPanel.

---

## Local run (on your computer)
```bash
npm install
cp .env.example .env       # DATABASE_URL=file:./db/custom.db
npx prisma db push
npm run dev                # http://localhost:3000
```

## Notes
- Contact form messages are stored in the SQLite database.
  On Vercel free tier the filesystem is temporary — messages survive until the
  next redeploy. For permanent storage ask your developer to connect a free
  cloud database (Turso / Neon) — 10 minute job.
- Update site content (texts, services, team, blog) in: `src/lib/*.ts`
- Brand colors & theme: `src/app/globals.css` (brand = #ED1C24 red)
- Logo & images: `public/` folder
